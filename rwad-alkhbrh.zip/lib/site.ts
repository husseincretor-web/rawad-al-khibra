/**
 * جميع بيانات النشاط التجاري في مكان واحد.
 * عند تغيير أي معلومة (رقم، عنوان، صور) عدّل هذا الملف فقط.
 */

export const site = {
  name: 'رواد الخبره لزينه السيارات',
  shortName: 'رواد الخبره',
  activity: 'تاجر جملة اكسسوارات سيارات',
  city: 'ينبع',
  address: {
    street: 'الملك فهد، الصهاريج',
    city: 'ينبع',
    postalCode: '46413',
    country: 'المملكة العربية السعودية',
    full: 'الملك فهد، الصهاريج، ينبع 46413، المملكة العربية السعودية',
  },
  phone: {
    display: '+966 57 407 5786',
    tel: 'tel:+966574075786',
    e164: '+966574075786',
    whatsapp: 'https://wa.me/966574075786',
  },
  maps:
    'https://www.google.com/maps/search/?api=1&query=' +
    encodeURIComponent('الملك فهد الصهاريج ينبع 46413 السعودية'),
  rating: {
    value: '5.0',
    count: 1,
  },
  review: {
    text: 'انصح بتعامل معهم بشده اتقان وعمل واخلاق وبعتمد المحل',
    author: 'الحطام',
  },
  url: process.env.NEXT_PUBLIC_SITE_URL ?? 'https://rowad-alkhbra.vercel.app',
} as const

export const navLinks = [
  { href: '#home', label: 'الرئيسية' },
  { href: '#about', label: 'من نحن' },
  { href: '#services', label: 'الخدمات' },
  { href: '#gallery', label: 'معرض الصور' },
  { href: '#reviews', label: 'آراء العملاء' },
  { href: '#location', label: 'موقعنا' },
  { href: '#contact', label: 'تواصل معنا' },
] as const

/**
 * معرض الصور.
 * ضع الصور الحقيقية في مجلد public/images بنفس الاسم المذكور في `file`
 * (يفضل صيغة WebP أو AVIF)، ثم غيّر `src` إلى `/images/اسم-الصورة.webp`.
 * الخانات التي قيمة src فيها null تظهر كإطار فارغ بدون أي صورة وهمية.
 */
export type GalleryItem = {
  file: string
  src: string | null
  alt: string
}

/** صورة الغلاف الرئيسية (Hero) وصورة قسم «من نحن». نفس طريقة الاستبدال. */
export const heroImage: GalleryItem = {
  file: 'hero.webp',
  src: null,
  alt: 'واجهة محل رواد الخبره لزينه السيارات في ينبع',
}

export const aboutImage: GalleryItem = {
  file: 'about.webp',
  src: null,
  alt: 'داخل محل رواد الخبره لزينه السيارات',
}

export const gallery: GalleryItem[] = [
  { file: 'gallery-1.webp', src: null, alt: 'واجهة محل رواد الخبره لزينه السيارات في ينبع' },
  { file: 'gallery-2.webp', src: null, alt: 'عرض اكسسوارات السيارات داخل المحل' },
  { file: 'gallery-3.webp', src: null, alt: 'قسم زينة السيارات في المحل' },
  { file: 'gallery-4.webp', src: null, alt: 'منتجات وإكسسوارات متوفرة لدى رواد الخبره' },
  { file: 'gallery-5.webp', src: null, alt: 'خدمة تركيب اكسسوارات السيارات' },
  { file: 'gallery-6.webp', src: null, alt: 'صور من داخل معرض رواد الخبره لزينه السيارات' },
]
